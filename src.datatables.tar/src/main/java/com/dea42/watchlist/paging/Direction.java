package com.dea42.watchlist.paging;

public enum Direction {

	asc, desc;
}
