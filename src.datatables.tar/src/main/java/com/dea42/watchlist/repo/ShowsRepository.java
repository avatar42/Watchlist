package com.dea42.watchlist.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dea42.watchlist.entity.Shows;

/**
 * Title: ShowsRepository <br>
 * Description: Class for the Shows Repository. <br>
 * Copyright: Copyright (c) 2001-2021<br>
 * Company: RMRR<br>
 * 
 * @author Gened by com.dea42.build.GenSpring version 0.6.5<br>
 * @version 0.6.5<br>
 */
@Repository
public interface ShowsRepository extends CrudRepository<Shows, Integer>, JpaSpecificationExecutor<Shows> {

//	List<Shows> findByCancelledLikeOrEpguidesshownameLikeOrIncanceledasLikeOrLastshowLikeOrNetworkLikeOrPremiereLikeOrStatusLikeOrTivonameLike(
//			String cancelled, String epguidesshowname, String incanceledas, String lastshow, String network,
//			String premiere, String status, String tivoname);

//	@Query("select u from Shows u where u.cancelled like %?1%" + " OR u.epguidesshowname like %?1%"
//			+ " OR u.incanceledas like %?1%" + " OR u.lastshow like %?1%" + " OR u.network like %?1%"
//			+ " OR u.premiere like %?1%" + " OR u.status like %?1%" + " OR u.tivoname like %?1%")
//	List<Shows> findByCancelled(String value);

}
