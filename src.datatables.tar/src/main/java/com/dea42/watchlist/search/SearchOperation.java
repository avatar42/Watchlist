package com.dea42.watchlist.search;

/**
 * Supported search ops
 * 
 * @author Gened by com.dea42.build.GenSpring version 0.6.5<br>
 * @version 0.6.5<br>
 *
 */
public enum SearchOperation {
//    GREATER_THAN,
//    LESS_THAN,
    GREATER_THAN_EQUAL,
    LESS_THAN_EQUAL,
//    NOT_EQUAL,
//    EQUAL,
    LIKE
//    MATCH,
//    MATCH_START,
//    MATCH_END,
//    IN,
//    NOT_IN
}
