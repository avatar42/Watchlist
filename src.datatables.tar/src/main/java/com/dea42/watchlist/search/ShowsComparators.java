package com.dea42.watchlist.search;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import com.dea42.watchlist.entity.Shows;
import com.dea42.watchlist.paging.Direction;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

public class ShowsComparators {
	@EqualsAndHashCode
	@AllArgsConstructor
	@Getter
	static class Key {
		String name;
		Direction dir;
	}

	static Map<Key, Comparator<Shows>> map = new HashMap<>();

	static {
		map.put(new Key("cancelled", Direction.asc), Comparator.comparing(Shows::getCancelled));
		map.put(new Key("cancelled", Direction.desc), Comparator.comparing(Shows::getCancelled).reversed());

		map.put(new Key("epguidesshowname", Direction.asc), Comparator.comparing(Shows::getEpguidesshowname));
		map.put(new Key("epguidesshowname", Direction.desc), Comparator.comparing(Shows::getEpguidesshowname).reversed());

		map.put(new Key("incanceledas", Direction.asc), Comparator.comparing(Shows::getIncanceledas));
		map.put(new Key("incanceledas", Direction.desc), Comparator.comparing(Shows::getIncanceledas).reversed());

		map.put(new Key("lastshow", Direction.asc), Comparator.comparing(Shows::getLastshow));
		map.put(new Key("lastshow", Direction.desc), Comparator.comparing(Shows::getLastshow).reversed());

		map.put(new Key("network", Direction.asc), Comparator.comparing(Shows::getNetwork));
		map.put(new Key("network", Direction.desc), Comparator.comparing(Shows::getNetwork).reversed());

		map.put(new Key("premiere", Direction.asc), Comparator.comparing(Shows::getPremiere));
		map.put(new Key("premiere", Direction.desc), Comparator.comparing(Shows::getPremiere).reversed());

		map.put(new Key("premieredate", Direction.asc), Comparator.comparing(Shows::getPremieredate));
		map.put(new Key("premieredate", Direction.desc), Comparator.comparing(Shows::getPremieredate).reversed());

		map.put(new Key("status", Direction.asc), Comparator.comparing(Shows::getStatus));
		map.put(new Key("status", Direction.desc), Comparator.comparing(Shows::getStatus).reversed());

		map.put(new Key("tivoname", Direction.asc), Comparator.comparing(Shows::getTivoname));
		map.put(new Key("tivoname", Direction.desc), Comparator.comparing(Shows::getTivoname).reversed());

	}

	public static Comparator<Shows> getComparator(String name, Direction dir) {
		return map.get(new Key(name, dir));
	}

	private ShowsComparators() {
	}
}
