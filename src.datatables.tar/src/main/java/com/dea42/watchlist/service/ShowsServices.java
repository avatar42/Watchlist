package com.dea42.watchlist.service;

//import java.io.IOException;
//import java.util.Comparator;
import java.util.Date;
//import java.util.List;
//import java.util.function.Predicate;
//import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.dea42.watchlist.entity.Shows;
import com.dea42.watchlist.paging.Column;
import com.dea42.watchlist.paging.Direction;
import com.dea42.watchlist.paging.Order;
import com.dea42.watchlist.paging.PageInfo;
import com.dea42.watchlist.paging.PagingRequest;
import com.dea42.watchlist.repo.ShowsRepository;
import com.dea42.watchlist.search.SearchCriteria;
import com.dea42.watchlist.search.SearchOperation;
import com.dea42.watchlist.search.SearchSpecification;
//import com.dea42.watchlist.search.ShowsComparators;
import com.dea42.watchlist.search.ShowsSearchForm;

import lombok.extern.slf4j.Slf4j;

/**
 * Title: ShowsServices <br>
 * Description: ShowsServices. <br>
 * Copyright: Copyright (c) 2001-2021<br>
 * Company: RMRR<br>
 * 
 * @author Gened by com.dea42.build.GenSpring version 0.6.5<br>
 * @version 0.6.5<br>
 */
@Slf4j
@Service
public class ShowsServices {
	@Autowired
	private ShowsRepository showsRepository;

	public Page<Shows> listAll(ShowsSearchForm form) {
		SearchSpecification<Shows> searchSpec = new SearchSpecification<Shows>(form.isDoOr());
		if (form != null) {
			log.debug(form.toString());
			if (form.getIdMin() != null) {
				searchSpec.add(new SearchCriteria<Integer>("id", form.getIdMin(), SearchOperation.GREATER_THAN_EQUAL));
			}
			if (form.getIdMax() != null) {
				searchSpec.add(new SearchCriteria<Integer>("id", form.getIdMax(), SearchOperation.LESS_THAN_EQUAL));
			}
			if (!StringUtils.isBlank(form.getCancelled())) {
				searchSpec.add(new SearchCriteria<String>("cancelled", form.getCancelled().toLowerCase(),
						SearchOperation.LIKE));
			}
			if (!StringUtils.isBlank(form.getEpguidesshowname())) {
				searchSpec.add(new SearchCriteria<String>("epguidesshowname", form.getEpguidesshowname().toLowerCase(),
						SearchOperation.LIKE));
			}
			if (form.getIdMin() != null) {
				searchSpec.add(new SearchCriteria<Integer>("id", form.getIdMin(), SearchOperation.GREATER_THAN_EQUAL));
			}
			if (form.getIdMax() != null) {
				searchSpec.add(new SearchCriteria<Integer>("id", form.getIdMax(), SearchOperation.LESS_THAN_EQUAL));
			}
			if (!StringUtils.isBlank(form.getIncanceledas())) {
				searchSpec.add(new SearchCriteria<String>("incanceledas", form.getIncanceledas().toLowerCase(),
						SearchOperation.LIKE));
			}
			if (!StringUtils.isBlank(form.getLastshow())) {
				searchSpec.add(
						new SearchCriteria<String>("lastshow", form.getLastshow().toLowerCase(), SearchOperation.LIKE));
			}
			if (!StringUtils.isBlank(form.getNetwork())) {
				searchSpec.add(
						new SearchCriteria<String>("network", form.getNetwork().toLowerCase(), SearchOperation.LIKE));
			}
			if (!StringUtils.isBlank(form.getPremiere())) {
				searchSpec.add(
						new SearchCriteria<String>("premiere", form.getPremiere().toLowerCase(), SearchOperation.LIKE));
			}

			if (form.getPremieredateMin() != null) {
// need to subtract a millsec here to get >= same to work reliably.
				searchSpec.add(new SearchCriteria<Date>("premieredate",
						new Date(form.getPremieredateMin().getTime() - 1), SearchOperation.GREATER_THAN_EQUAL));
			}
			if (form.getPremieredateMax() != null) {
// need to add a millsec here to get <= same to work reliably.
				searchSpec.add(new SearchCriteria<Date>("premieredate",
						new Date(form.getPremieredateMax().getTime() + 1), SearchOperation.LESS_THAN_EQUAL));
			}
			if (!StringUtils.isBlank(form.getStatus())) {
				searchSpec.add(
						new SearchCriteria<String>("status", form.getStatus().toLowerCase(), SearchOperation.LIKE));
			}
			if (!StringUtils.isBlank(form.getTivoname())) {
				searchSpec.add(
						new SearchCriteria<String>("tivoname", form.getTivoname().toLowerCase(), SearchOperation.LIKE));
			}

		} else {
			form = new ShowsSearchForm();
		}
		Pageable pageable = PageRequest.of(form.getPage() - 1, form.getPageSize(), form.getSort());
		if (log.isInfoEnabled())
			log.info("searchSpec:" + searchSpec);
		return showsRepository.findAll(searchSpec, pageable);
	}

	public Shows save(Shows shows) {
		return showsRepository.save(shows);
	}

	public Shows get(Integer id) {
		return showsRepository.findById(id).get();
	}

	public void delete(Integer id) {
		showsRepository.deleteById(id);
	}

//	private static final Comparator<Shows> EMPTY_COMPARATOR = (e1, e2) -> 0;

	public PageInfo<Shows> getShowss(ShowsSearchForm form, PagingRequest pagingRequest) {

		form.setPage(pagingRequest.getStart() + 1);
		form.setPageSize(pagingRequest.getLength());
		if (StringUtils.isNotBlank(pagingRequest.getSearch().getValue())) {
			String value = "%" + pagingRequest.getSearch().getValue() + "%";
			log.info("Searching for:" + value);
			form.setCancelled(value);
			form.setEpguidesshowname(value);
			form.setIncanceledas(value);
			form.setLastshow(value);
			form.setNetwork(value);
			form.setPremiere(value);
			form.setStatus(value);
			form.setTivoname(value);
			form.setDoOr(true);
		}
		Order order = pagingRequest.getOrder().get(0);
		int columnIndex = order.getColumn();
		Column column = pagingRequest.getColumns().get(columnIndex);
		form.setSortField(column.getData());
		form.setSortAsc(order.getDir().equals(Direction.asc));

		Page<Shows> filtered = listAll(form);
		int count = (int) filtered.getTotalElements();

//		List<Shows> filtered = showsRepository.findByCancelled(value);
//				.findByCancelledLikeOrEpguidesshownameLikeOrIncanceledasLikeOrLastshowLikeOrNetworkLikeOrPremiereLikeOrStatusLikeOrTivonameLike(
//						value, value, value, value, value, value, value, value);
//		filtered = filtered.stream()
//              .sorted(sortShowss(pagingRequest))
////              .filter(filterShowss(pagingRequest))
//              .skip(pagingRequest.getStart())
//              .limit(pagingRequest.getLength())
//              .collect(Collectors.toList());
//		int count = filtered.size();
//		int pages = (int) Math.ceil(count / pagingRequest.getLength());
//		form.setTotalPages(pages);
//		form.setTotalItems(count);
//
		PageInfo<Shows> pageInfo = new PageInfo<Shows>(filtered);
		pageInfo.setRecordsFiltered(count);
		pageInfo.setRecordsTotal(count);
		pageInfo.setDraw(pagingRequest.getDraw());

		return pageInfo;
//		return getPage(filtered, pagingRequest);
	}

//	private PageInfo<Shows> getPage(List<Shows> showss, PagingRequest pagingRequest) {
//		List<Shows> filtered = showss.stream().sorted(sortShowss(pagingRequest))
////                                           .filter(filterShowss(pagingRequest))
//				.skip(pagingRequest.getStart()).limit(pagingRequest.getLength()).collect(Collectors.toList());
//
//		long count = showss.size();
////        long count = showss.stream()
////                             .filter(filterShowss(pagingRequest))
////                             .count();
//
//		PageInfo<Shows> pageInfo = new PageInfo<Shows>(filtered);
//		pageInfo.setRecordsFiltered((int) count);
//		pageInfo.setRecordsTotal((int) count);
//		pageInfo.setDraw(pagingRequest.getDraw());
//
//		return pageInfo;
//	}
//
//	private Comparator<Shows> sortShowss(PagingRequest pagingRequest) {
//		if (pagingRequest.getOrder() == null) {
//			return EMPTY_COMPARATOR;
//		}
//
//		try {
//			Order order = pagingRequest.getOrder().get(0);
//
//			int columnIndex = order.getColumn();
//			Column column = pagingRequest.getColumns().get(columnIndex);
//
//			Comparator<Shows> comparator = ShowsComparators.getComparator(column.getData(), order.getDir());
//			if (comparator == null) {
//				return EMPTY_COMPARATOR;
//			}
//
//			return comparator;
//
//		} catch (Exception e) {
//			log.error(e.getMessage(), e);
//		}
//
//		return EMPTY_COMPARATOR;
//	}
}
